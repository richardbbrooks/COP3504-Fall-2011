VISUAL INSPECTION OF THE METHODS WAS PERFORMED

Tested positive and negative numbers/angles - results were as expected.
Tested the different facing options for letterC() - results were as required.

The DrawMugs driver program served as very good testing. Clearly, if the methods didn't perform as required drawing the mugs and shapes wouldn't be possible.
